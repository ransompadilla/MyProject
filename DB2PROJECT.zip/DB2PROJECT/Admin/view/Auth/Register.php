<?php include 'view/Auth/Authheader.php';?>
      <script type="text/javascript">
        var prompt = prompt("Password");
        if(prompt != "admin_123"){
          alert("Invalid Password");
          window.location = "index.php?auth=Login";
        }
      </script>
      <form class="login-form" method="POST" action="../Controller/RegisterController.php">        
        <div class="login-wrap">
            <p class="login-img"><i class="icon_lock_alt"></i></p>
            <div class="input-group">
              <span class="input-group-addon"><i class="icon_profile"></i></span>
              <input type="text" name="name" class="form-control" placeholder="Name" autofocus>
            </div>
            <div class="input-group">
              <span class="input-group-addon"><i class="icon_profile"></i></span>
              <input type="text" name="contact" class="form-control" placeholder="Contact" autofocus>
            </div>
            <div class="input-group">
              <span class="input-group-addon"><i class="icon_profile"></i></span>
              <input type="file" name="img" class="form-control" placeholder="image" autofocus>
            </div>

            <div class="input-group">
                <span class="input-group-addon"><i class="icon_profile"></i></span>
                <input type="email" name="username" class="form-control" placeholder="Username">
            </div>
            <div class="input-group">
                <span class="input-group-addon"><i class="icon_key_alt"></i></span>
                <input type="password" name="password" class="form-control" placeholder="Password">
            </div>
            <div class="input-group">
                <span class="input-group-addon"><i class="icon_key_alt"></i></span>
                <input type="password" name="Re-Password"class="form-control" placeholder="Re-Password">
            </div>
            <button class="btn btn-primary btn-lg btn-block" name="register_admin" type="submit">Submit</button>
            <a href="index.php?auth=Login" class="btn btn-info btn-lg btn-block" type="submit">Cancel</a>
        </div>
      </form>
<?php include 'view/Auth/AuthFooter.php';?>