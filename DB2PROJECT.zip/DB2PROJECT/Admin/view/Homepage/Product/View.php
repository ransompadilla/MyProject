              <div class="row">
                  <div class="col-lg-12">
                      <section class="panel">
                          <header class="panel-heading">
                              Product Record
                          </header>
                          <div class="table-responsive">
                            <table class="table">
                           <tbody>
                              <tr>
                                 <th><i class="icon_key_alt"></i>_CODE</th>
                                 <th><i class="fa fa-list"></i>_Description</th>
                                 <th><i class="icon_calendar"></i>_Quantity</th>
                                 <th><i class="icon_profile"></i>_Price</th>
                                 <th><i class="icon_cogs"></i>_Action</th>
                              </tr>          
                                <?php
								        if(count($product) > 0){
								        	
								        	foreach ($product as $key) { 
								        		  if(isset($_COOKIE['update'])){
                                if($_COOKIE['update'] == $key['prod_id']){
                                  echo "<tr style='background-color:#e0e0e0;'>";
                                    echo "<td>".$key['prod_code']."</td>";
                                    echo "<td>".$key['prod_description']."</td>";
                                    echo "<td>".$key['prod_qty']."</td>";
                                    echo "<td>".$key['prod_price']."</td>";
                                    echo "<td><a href='index.php?homepage=Product/Update&prod_id=".$key['prod_id']."&prod_code=".$key['prod_code']."&prod_desc=".$key['prod_description']."&prod_qty=".$key['prod_qty']."&prod_price=".$key['prod_price']."' class='glyphicon glyphicon-edit'> </a>   <a href='#' id='".$key['prod_id']."' class='deleteProduct glyphicon glyphicon-trash'> </a></td>";
                                  echo "</tr>";
                                }
                                else{
                                  echo "<tr>";
                                    echo "<td>".$key['prod_code']."</td>";
                                    echo "<td>".$key['prod_description']."</td>";
                                    echo "<td>".$key['prod_qty']."</td>";
                                    echo "<td>".$key['prod_price']."</td>";
                                    echo "<td><a href='index.php?homepage=Product/Update&prod_id=".$key['prod_id']."&prod_code=".$key['prod_code']."&prod_desc=".$key['prod_description']."&prod_qty=".$key['prod_qty']."&prod_price=".$key['prod_price']."' class='glyphicon glyphicon-edit'> </a>   <a href='#' id='".$key['prod_id']."' class='deleteProduct glyphicon glyphicon-trash'> </a></td>";
                                  echo "</tr>";
                                }
                              }
                              else{
                                echo "<tr>";
                                  echo "<td>".$key['prod_code']."</td>";
                                  echo "<td>".$key['prod_description']."</td>";
                                  echo "<td>".$key['prod_qty']."</td>";
                                  echo "<td>".$key['prod_price']."</td>";
                                  echo "<td><a href='index.php?homepage=Product/Update&prod_id=".$key['prod_id']."&prod_code=".$key['prod_code']."&prod_desc=".$key['prod_description']."&prod_qty=".$key['prod_qty']."&prod_price=".$key['prod_price']."' class='glyphicon glyphicon-edit'> </a>   <a href='#' id='".$key['prod_id']."' class='deleteProduct glyphicon glyphicon-trash'> </a></td>";
                                echo "</tr>";
                              }
								        	}
								            
								        }
								?>                    
                           </tbody>
                        </table>
                        </div>
                      </section>
                  </div>
              </div>