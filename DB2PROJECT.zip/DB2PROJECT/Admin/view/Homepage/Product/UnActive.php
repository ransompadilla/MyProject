              <div class="row">
                  <div class="col-lg-12">
                      <section class="panel">
                          <header class="panel-heading">
                              Product Record
                          </header>
                          <div class="table-responsive">
                            <table class="table">
                           <tbody>
                              <tr>
                                 <th><i class="icon_key_alt"></i>_CODE</th>
                                 <th><i class="fa fa-list"></i>_Description</th>
                                 <th><i class="icon_calendar"></i>_Quantity</th>
                                 <th><i class="icon_profile"></i>_Price</th>
                                 <th><i class="icon_cogs"></i>_Action</th>
                              </tr>          
                                <?php
								        if(count($unactive_product) > 0){
								        	
								        	foreach ($unactive_product as $key) { 
								        		echo "<tr>";
								                echo "<td>".$key['prod_code']."</td>";
								                echo "<td>".$key['prod_description']."</td>";
								                echo "<td>".$key['prod_qty']."</td>";
								                echo "<td>".$key['prod_price']."</td>";
								                echo "<td><a href='#' id='".$key['prod_id']."' class='activeProd btn btn-primary'> ACTIVATE</a></td>";
								                echo "</tr>";
								        	}
								            
								        }
								?>                    
                           </tbody>
                        </table>
                        </div>
                      </section>
                  </div>
              </div>