<?php
    $prod_id = $_GET['prod_id'];
    $prod_code = $_GET['prod_code'];
    $prod_desc = $_GET['prod_desc'];
    $prod_qty = $_GET['prod_qty'];
    $prod_price = $_GET['prod_price'];
?>
              <div class="panel panel-default">
                <div class="panel-heading">
                  <div class="pull-left">Update Product</div>
                  <div class="widget-icons pull-right">
                    <a href="#" class="wminimize"><i class="fa fa-chevron-up"></i></a> 
                    <a href="#" class="wclose"><i class="fa fa-times"></i></a>
                  </div>  
                  <div class="clearfix"></div>
                </div>
                <div class="panel-body">
                  <div class="padd">
                    
                      <div class="form quick-post">
                                      <!-- Edit profile form (not working)-->
                                      <form class="form-horizontal" method="POST">
                                          <!-- Title -->
                                          <input type="hidden" name="prod_id" value="<?php echo $prod_id;?>" class="form-control" id="title">
                                          <div class="form-group">
                                            <label class="control-label col-lg-2" for="title">Product CODE</label>
                                            <div class="col-lg-10"> 
                                              <input type="text" name="prod_code" value="<?php echo $prod_code;?>" class="form-control" id="title">
                                            </div>
                                          </div>   
                                          <!-- Content -->
                                          <div class="form-group">
                                            <label class="control-label col-lg-2" for="content">Product Description</label>
                                            <div class="col-lg-10">
                                              <textarea class="form-control" name="prod_desc" id="content"><?php echo $prod_desc;?></textarea>
                                            </div>
                                          </div>                           
                                          <!-- Cateogry -->
                                          <div class="form-group">
                                            <label class="control-label col-lg-2" for="tags">Product Quantity</label>
                                            <div class="col-lg-10">
                                              <input type="text" name="prod_qty" value="<?php echo $prod_qty;?>" class="form-control" id="tags">
                                            </div>
                                          </div>            
                                          <!-- Tags -->
                                          <div class="form-group">
                                            <label class="control-label col-lg-2" for="tags">Product Price</label>
                                            <div class="col-lg-10">
                                              <input type="text" name="prod_price" value="<?php echo $prod_price;?>" class="form-control" id="tags">
                                            </div>
                                          </div>
                                          
                                          <!-- Buttons -->
                                          <div class="form-group">
                                             <!-- Buttons -->
                                         <div class="col-lg-offset-2 col-lg-9">
                                          <button type="submit" class="btn btn-primary" name="update_product">Update</button>
                                          <a class="btn btn-default" href="index.php?homepage=Product/View">Cancel</a>
                                         </div>
                                          </div>
                                      </form>
                                    </div>
                  

                  </div>
                  <div class="widget-foot">
                    <!-- Footer goes here -->
                  </div>
                </div>
              </div>
            