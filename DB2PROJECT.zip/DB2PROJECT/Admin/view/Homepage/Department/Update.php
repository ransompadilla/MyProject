<?php 
    $dept_id = $_GET['dept_id'];
    $dept_code = $_GET['dept_code'];
    $dept_name = $_GET['dept_name'];
?>
              <div class="panel panel-default">
                <div class="panel-heading">
                  <div class="pull-left">Update Department</div>
                  <div class="widget-icons pull-right">
                    <a href="#" class="wminimize"><i class="fa fa-chevron-up"></i></a> 
                    <a href="index.php?homepage=Department/View" class="wclose"><i class="fa fa-times"></i></a>
                  </div>  
                  <div class="clearfix"></div>
                </div>
                <div class="panel-body">
                  <div class="padd">
                    
                      <div class="form quick-post">
                                      <!-- Edit profile form (not working)-->
                                      <form class="form-horizontal" method="POST">
                                          <!-- Title -->
                                          <input type="hidden" name="dept_id" value="<?php echo $dept_id;?>" class="form-control" id="title" required="">
                                          <div class="form-group">
                                            <label class="control-label col-lg-2" for="title">Department CODE</label>
                                            <div class="col-lg-10"> 
                                              <input type="text" name="dept_code" value="<?php echo $dept_code;?>" class="form-control" id="title" required="">
                                            </div>
                                          </div>   
                                          <!-- Content -->
                                          <div class="form-group">
                                            <label class="control-label col-lg-2" for="content">Department Description</label>
                                            <div class="col-lg-10">
                                              <textarea class="form-control" name="dept_name" id="content"><?php echo $dept_name?></textarea>
                                            </div>
                                          </div> 
                                          <!-- Buttons -->
                                          <div class="form-group">
                                             <!-- Buttons -->
                                         <div class="col-lg-offset-2 col-lg-9">
                                          <button type="submit" class="btn btn-primary" name="update_department">Update</button>
                                          <a href="index.php?homepage=Department/View" class="btn btn-default">Cancel</a>
                                         </div>
                                          </div>
                                      </form>
                                    </div>
                  

                  </div>
                  <div class="widget-foot">
                    <!-- Footer goes here -->
                  </div>
                </div>
              </div>
            