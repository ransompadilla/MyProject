
              <div class="row">
                  <div class="col-lg-12">
                      <section class="panel">
                          <header class="panel-heading">
                              Employee Record
                          </header>
                          <div class="table-responsive">
                            <table class="table">
                           <tbody>
                              <tr>
                                 <th><i class="icon_profile"></i>_ID</th>
                                 <th><i class="icon_profile"></i>_Name</th>
                                 <th><i class="icon_calendar"></i>_Age</th>
                                 <th><i class="icon_profile"></i>_Gender</th>
                                 <th><i class="icon_pin_alt"></i>_Address</th>
                                 <th><i class="icon_mobile"></i>_Mobile</th>
                                 <th><i class="fa fa-list"></i>_DEPT</th>
                                 <th><i class="fa fa-list"></i>_Pos</th>
                                 <th><i class="icon_cogs"></i>_Action</th>
                              </tr>          
                              <?php
                                    if(count($unactive_employee) > 0){
                                        
                                        foreach ($unactive_employee as $key) { 
                                            echo "<tr>";
                                            echo "<td>".$key['emp_id']."</td>";
                                            echo "<td>".$key['emp_lname'].", ".$key['emp_fname']."</td>";
                                            echo "<td>".$key['emp_age']."</td>";
                                            echo "<td>".$key['emp_gender']."</td>";
                                            echo "<td>".$key['emp_address']."</td>";
                                            echo "<td>".$key['emp_contact']."</td>";
                                            echo "<td>".$key['dept_name']."</td>";
                                            echo "<td>".$key['emp_position']."</td>";
                                            echo "<td><a href='#' id='".$key['emp_id']."' class='activeEmp btn btn-primary'> ACTIVATE</a></td>";
                                            echo "</tr>";
                                        }
                                        
                                    }
                            ?>                    
                           </tbody>
                        </table>
                        </div>
                      </section>
                  </div>
              </div>