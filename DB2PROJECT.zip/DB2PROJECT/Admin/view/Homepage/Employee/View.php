
              <div class="row">
                  <div class="col-lg-12">
                      <section class="panel">
                          <header class="panel-heading">
                              Employee Record
                          </header>
                          <div class="table-responsive">
                            <table class="table">
                           <tbody>
                              <tr>
                                 <th><i class="icon_profile"></i>_ID</th>
                                 <th><i class="icon_profile"></i>_Name</th>
                                 <th><i class="icon_calendar"></i>_Age</th>
                                 <th><i class="icon_profile"></i>_Gender</th>
                                 <th><i class="icon_pin_alt"></i>_Address</th>
                                 <th><i class="icon_mobile"></i>_Mobile</th>
                                 <th><i class="fa fa-list"></i>_DEPT</th>
                                 <th><i class="fa fa-list"></i>_Pos</th>
                                 <th><i class="icon_cogs"></i>_Action</th>
                              </tr>          
                              <?php
                                    if(count($employee) > 0){
                                        
                                        foreach ($employee as $key) { 
                                          if(isset($_COOKIE['update'])){
                                            if ($_COOKIE['update'] == $key['emp_id']) {
                                              echo "<tr style='background-color:#d0d0d0;'>";
                                              echo "<td>".$key['emp_id']."</td>";
                                              echo "<td>".$key['emp_lname'].", ".$key['emp_fname']."</td>";
                                              echo "<td>".$key['emp_age']."</td>";
                                              echo "<td>".$key['emp_gender']."</td>";
                                              echo "<td>".$key['emp_address']."</td>";
                                              echo "<td>".$key['emp_contact']."</td>";
                                              echo "<td>".$key['dept_name']."</td>";
                                              echo "<td>".$key['emp_position']."</td>";
                                              echo "<td><a href='index.php?homepage=Employee/Update&id=".$key['emp_id']."&lname=".$key['emp_lname']."&fname=".$key['emp_fname']."&age=".$key['emp_age']."&gender=".$key['emp_gender']."&address=".$key['emp_address']."&contact=".$key['emp_contact']."&dept=".$key['dept_id']."&position=".$key['emp_position']."&' class='glyphicon glyphicon-edit'> </a>   <a href='#' id='".$key['emp_id']."' class='deleteEmployee glyphicon glyphicon-trash'> </a></td>";
                                              echo "</tr>";
                                            }
                                            else{
                                              echo "<tr>";
                                              echo "<td>".$key['emp_id']."</td>";
                                              echo "<td>".$key['emp_lname'].", ".$key['emp_fname']."</td>";
                                              echo "<td>".$key['emp_age']."</td>";
                                              echo "<td>".$key['emp_gender']."</td>";
                                              echo "<td>".$key['emp_address']."</td>";
                                              echo "<td>".$key['emp_contact']."</td>";
                                              echo "<td>".$key['dept_name']."</td>";
                                              echo "<td>".$key['emp_position']."</td>";
                                              echo "<td><a href='index.php?homepage=Employee/Update&id=".$key['emp_id']."&lname=".$key['emp_lname']."&fname=".$key['emp_fname']."&age=".$key['emp_age']."&gender=".$key['emp_gender']."&address=".$key['emp_address']."&contact=".$key['emp_contact']."&dept=".$key['dept_id']."&position=".$key['emp_position']."&' class='glyphicon glyphicon-edit'> </a>   <a href='#' id='".$key['emp_id']."' class='deleteEmployee glyphicon glyphicon-trash'> </a></td>";
                                              echo "</tr>";
                                            }
                                            
                                        }
                                        else{
                                          echo "<tr>";
                                            echo "<td>".$key['emp_id']."</td>";
                                            echo "<td>".$key['emp_lname'].", ".$key['emp_fname']."</td>";
                                            echo "<td>".$key['emp_age']."</td>";
                                            echo "<td>".$key['emp_gender']."</td>";
                                            echo "<td>".$key['emp_address']."</td>";
                                            echo "<td>".$key['emp_contact']."</td>";
                                            echo "<td>".$key['dept_name']."</td>";
                                            echo "<td>".$key['emp_position']."</td>";
                                            echo "<td><a href='index.php?homepage=Employee/Update&id=".$key['emp_id']."&lname=".$key['emp_lname']."&fname=".$key['emp_fname']."&age=".$key['emp_age']."&gender=".$key['emp_gender']."&address=".$key['emp_address']."&contact=".$key['emp_contact']."&dept=".$key['dept_id']."&position=".$key['emp_position']."&' class='glyphicon glyphicon-edit'> </a>   <a href='#' id='".$key['emp_id']."' class='deleteEmployee glyphicon glyphicon-trash'> </a></td>";
                                            echo "</tr>";
                                        }
                                      }
                                    }
                            ?>                    
                           </tbody>
                        </table>
                        </div>
                      </section>
                  </div>
              </div>