
              <div class="panel panel-default">
                <div class="panel-heading">
                  <div class="pull-left">Register Employee</div>
                  <div class="widget-icons pull-right">
                    <a href="#" class="wminimize"><i class="fa fa-chevron-up"></i></a> 
                    <a href="#" class="wclose"><i class="fa fa-times"></i></a>
                  </div>  
                  <div class="clearfix"></div>
                </div>
                <div class="panel-body">
                  <div class="padd">
                    
                      <div class="form quick-post">
                                      <!-- Edit profile form (not working)-->
                                      <form class="form-horizontal" method="POST" action="index.php">
                                          <!-- Title -->
                                           <label class="control-label col-lg-2" for="title">First Name</label>
                                            <div class="col-lg-10 col-lg-6 col-lg-4">
                                              <div class="form-group">
                                                <input type="text" name="fname" class="form-control"  required="">
                                              </div>
                                            </div>
                                             <label class="control-label col-lg-2" for="title">Last Name</label>
                                            <div class="col-lg-10 col-lg-6 col-lg-4">
                                              <div class="form-group">
                                                <input type="text" name="lname" class="form-control"   required="">
                                              </div>
                                            </div>
                                          <div class="form-group">
                                            <label class="control-label col-lg-2" for="title">Age</label>
                                            <div class="col-lg-10"> 
                                              <input type="text" name="age" class="form-control" id="title" required="">
                                            </div>
                                          </div>   
                                          <!-- Content -->
                                          <div class="form-group">
                                            <label class="control-label col-lg-2" for="tags">Gender</label>
                                            <div class="col-lg-10">
                                              <select class="form-control" name="gender" required="">
                                                <option value=''>Choose Gender</option>
                                                <option value='M'>Male</option>
                                                <option value='F'>Female</option>
                                              </select>
                                            </div>
                                          </div>                    
                                          <!-- Cateogry -->
                                          <div class="form-group">
                                            <label class="control-label col-lg-2" for="tags">Address</label>
                                            <div class="col-lg-10">
                                              <input type="text" name="address" class="form-control" id="tags" required="">
                                            </div>
                                          </div>            
                                          <!-- Tags -->
                                          <div class="form-group">
                                            <label class="control-label col-lg-2" for="tags">Contact</label>
                                            <div class="col-lg-10">
                                              <input type="text" name="contact" class="form-control" id="tags">
                                            </div>
                                          </div>
                                          <div class="form-group">
                                            <label class="control-label col-lg-2" for="tags">Department</label>
                                            <div class="col-lg-10">
                                              <select class="form-control" name="department" required="">
                                              <option value="">Choose Department</option>
                                                <?php 
                                                if(count($department)>0){

                                                    foreach ($department as $key) {
                                                        echo "<option value='".$key['dept_id']."'>".$key['dept_name']."</option>";
                                                    }
                                                }
                                                ?>
                                              </select>
                                            </div>
                                          </div>
                                          <div class="form-group">
                                            <label class="control-label col-lg-2" for="tags">Position</label>
                                            <div class="col-lg-10">
                                              <input type="text" name="position" class="form-control" id="tags">
                                            </div>
                                          </div>
                                          <!-- Buttons -->
                                          <div class="form-group">
                                             <!-- Buttons -->
                                         <div class="col-lg-offset-2 col-lg-9">
                                          <button type="submit" class="btn btn-primary" name="register_employee">Save</button>
                                          <button type="reset" class="btn btn-default">Reset</button>
                                         </div>
                                          </div>
                                      </form>
                                    </div>
                  

                  </div>
                  <div class="widget-foot">
                    <!-- Footer goes here -->
                  </div>
                </div>
              </div>
            