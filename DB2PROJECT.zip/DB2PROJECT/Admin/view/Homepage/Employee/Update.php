<?php 
    $id = $_GET['id'];
    $lname = $_GET['lname'];
    $fname = $_GET['fname'];
    $age = $_GET['age'];
    $gender = $_GET['gender'];
    $address = $_GET['address'];
    $contact = $_GET['contact'];
    $dept = $_GET['dept'];
    $position = $_GET['position'];
    var_dump($id);

?>
              <div class="panel panel-default">
                <div class="panel-heading">
                  <div class="pull-left">Update Employee</div>
                  <div class="widget-icons pull-right">
                    <a href="#" class="wminimize"><i class="fa fa-chevron-up"></i></a> 
                    <a href="index.php?homepage=Employee/View" class="wclose"><i class="fa fa-times"></i></a>
                  </div>  
                  <div class="clearfix"></div>
                </div>
                <div class="panel-body">
                  <div class="padd">
                    
                      <div class="form quick-post">
                                      <!-- Edit profile form (not working)-->
                                      <form class="form-horizontal" method="POST">
                                          <!-- Title -->
                                          <input type="hidden" name="id" value="<?php echo $id;?>" class="form-control">
                                           <label class="control-label col-lg-2" for="title">First Name</label>
                                            <div class="col-lg-10 col-lg-6 col-lg-4">
                                              <div class="form-group">
                                                <input type="text" name="fname" value="<?php echo $fname;?>" class="form-control"  required="">
                                              </div>
                                            </div>
                                             <label class="control-label col-lg-2" for="title">Last Name</label>
                                            <div class="col-lg-10 col-lg-6 col-lg-4">
                                              <div class="form-group">
                                                <input type="text" name="lname" value="<?php echo $lname;?>" class="form-control"   required="">
                                              </div>
                                            </div>
                                          <div class="form-group">
                                            <label class="control-label col-lg-2" for="title">Age</label>
                                            <div class="col-lg-10"> 
                                              <input type="text" name="age" value="<?php echo $age;?>" class="form-control" id="title" required="">
                                            </div>
                                          </div>   
                                          <!-- Content -->
                                          <div class="form-group">
                                            <label class="control-label col-lg-2" for="tags">Gender</label>
                                            <div class="col-lg-10">
                                              <select class="form-control" name="gender" required="">
                                                <option value=''>Choose Gender</option>
                                                <option value='M' <?php if($gender == 'M') echo "Selected";?> >Male</option>
                                                <option value='F' <?php if($gender == 'F') echo "Selected";?>>Female</option>
                                              </select>
                                            </div>
                                          </div>                    
                                          <!-- Cateogry -->
                                          <div class="form-group">
                                            <label class="control-label col-lg-2" for="tags">Address</label>
                                            <div class="col-lg-10">
                                              <input type="text" name="address" value="<?php echo $address;?>" class="form-control" id="tags" required="">
                                            </div>
                                          </div>            
                                          <!-- Tags -->
                                          <div class="form-group">
                                            <label class="control-label col-lg-2" for="tags">Contact</label>
                                            <div class="col-lg-10">
                                              <input type="text" name="contact" value="<?php echo $contact;?>" class="form-control" id="tags">
                                            </div>
                                          </div>
                                          <div class="form-group">
                                            <label class="control-label col-lg-2" for="tags">Department</label>
                                            <div class="col-lg-10">
                                              <select class="form-control" name="department" required="">
                                                <?php 
                                                  if(count($department) > 0){
                                                      echo "<option value=''>Choose Department</option>";
                                                      foreach ($department as $key) {
                                                        if($dept == "".$key['dept_id'].""){
                                                          echo "<option value='".$key['dept_id']."' Selected>".$key['dept_name']."</option>";
                                                        }
                                                        else{
                                                          echo "<option value='".$key['dept_id']."'>".$key['dept_name']."</option>";
                                                        }
                                                      }
                                                  }
                                                ?>
                                              </select>
                                            </div>
                                          </div>
                                          <div class="form-group">
                                            <label class="control-label col-lg-2" for="tags">Position</label>
                                            <div class="col-lg-10">
                                              <input type="text" name="position" value="<?php echo $position;?>" class="form-control" id="tags">
                                            </div>
                                          </div>
                                          <!-- Buttons -->
                                          <div class="form-group">
                                             <!-- Buttons -->
                                         <div class="col-lg-offset-2 col-lg-9">
                                          <button type="submit" class="btn btn-primary" name="update_employee">Save</button>
                                          <a href="index.php?homepage=Employee/View" class="btn btn-default">Cancel</a>
                                         </div>
                                          </div>
                                      </form>
                                    </div>
                  

                  </div>
                  <div class="widget-foot">
                    <!-- Footer goes here -->
                  </div>
                </div>
              </div>
            