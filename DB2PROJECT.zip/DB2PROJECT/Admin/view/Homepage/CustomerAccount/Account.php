
              <div class="row">
                  <div class="col-lg-12">
                      <section class="panel">
                          <header class="panel-heading">
                              Customer Account
                          </header>
                          <div class="table-responsive">
                            <?php
                            if(count($payment) > 0){
                              echo "<table class='table table-stripped'>";
                              echo "<th>Name</th><th>Payment</th><th>Receivable</th><th>Balance</th>";

                              foreach ($payment as $v_p) {
                               $cust_id = $v_p['cust_id'];
                              $gross_rec = $this->model->GetGrossTotal($cust_id);
                              $_amount = $v_p['total_payment'];
                              $_balance = $gross_rec - $_amount;
                              
                                echo '<tr>';

                                  echo "<td><img class='img-circle' src='".$v_p['cust_img']."' width='50'> ".$v_p['cust_lname'].", ".$v_p['cust_fname']."
                                  <div class='panel-body' style='margin-left:15%;'><a data-toggle='modal' href='#order$cust_id' class='label label-primary'>order</a> &nbsp;<a data-toggle='modal' href='#payment$cust_id' class='label label-primary'> payment</a>
                                    </div>
                                    </td>";
                                  echo "<td>".$v_p['total_payment']."</td>";
                                  echo "<td>".$gross_rec."</td>";
                                  echo "<td><span style='color:red;'>".$_balance."</span></td>";
                                  echo "<td>

                                    </td>";

                                echo '</tr>';
                              }
                              echo '</table>';
                             
                            }
                            else {
                              echo "<div class='alert alert-danger alert-dismissable'><button type='button' class='close' data-dismiss='alert'aria-hidden='true'>&times;</button>NO PAYMENT RECORD... </div>";
                            }
                          ?>
                           
                          </div>

                      </section>
                  </div>
              </div>
              <?php
              for($i=$min;$i<$max;$i++){
                $customer = $this->model->GetCustomerInfo(array($i));
                $getCustPayment = $this->model->getCustomerPayment($i);
                $gross_rec = $this->model->GetGrossTotal($i);
                $order_list = $this->model->GetOrderList($i);
                $amount = $this->model->GetPayment($i);
                echo '<div class="modal fade" id="order'.$i.'" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                                  <div class="modal-dialog">
                                      <div class="modal-content">
                                          <div class="modal-header">
                                              <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                              <h4 class="modal-title">'.$customer['cust_fname'].''."'s".' Record</h4>
                                          </div>
                                          <div class="modal-body">

                                              <section class="panel" >
                                                  <div class="panel-body progress-panel">
                                                    <div class="row">
                                                      <div class="col-lg-8 task-progress pull-left">
                                                      
                                                        <img class="img-circle" src="'.$customer['cust_img'].'" width="50">
                                                         '.$customer['cust_lname'].', '.$customer['cust_fname'].'                              
                                                      </div>
                                                      <div class="col-lg-4">
                                                        <span class="profile-ava pull-right">';
                                                        
                                                          $balance = $gross_rec - $amount;
                                                          echo "<div style='margin-right:;'><b>Balance: $balance  <br>
                                                              Paid: $amount <br>Gross: $gross_rec</b></div>
                                                        
                                                              
                                                        </span>                                
                                                      </div>
                                                    </div>
                                                  </div>";
                                                  if(count($order_list) > 0){
                                                    foreach ($order_list as $k => $value) {
                                                        $d = strtotime($value['date_order']);
                                                        $date = Date("F j, Y",$d);

                                                        $date1 = Date("y-m-d",$d);
                                                       if(!$stack->isFind($date1)){
                                                          $stack->push($date1);
                                                        }
                                                    //}
                                                   // for($i=0;$i<$stack->count();$i++){
                                                      // $_date = $stack->itemsArray()[$i];
                                                      // $_dd = strtotime($_date);
                                                      // $_dateme = Date("F j, Y", $_dd);
                                                      $totalAmount = $this->model->GetTotalAmountPerDate($date1,$i);
                                                      echo '<div class="panel panel-default" style="margin-bottom:0px;">
                                                          <div class="panel-heading">
                                                            <h4 class="panel-title" style="margin-right:20px;">
                                                            <a data-toggle="collapse" href="#cust'.$i.'date'.$date1.'">'.$date.'</a>
                                                              <i class="pull-right"><strong> P'.$totalAmount.'</strong></i>
                                                                
                                                            </h4>
                                                          </div>
                                                          <div id="cust'.$i.'date'.$date1.'" class="panel-collapse collapse">';

                                              $order_info = $this->model->GetOrderInfo($date1,$i);
                                                          echo '<table class="table table-stripped" >
                                                              <th>CODE</th><th>QTY</th><th>PRICE</th><th>TOTAL</th>';

                                                      if(count($order_info) > 0){
                                                         $total=0;$atotal=0;
                                                            foreach ($order_info as $k => $key) {
                                                              $total = $key['prod_price'] * $key['order_qty'];
                                                              echo '<tr>
                                                                      <td>'.$key['prod_code'].'</td>
                                                                      <td>'.$key['order_qty'].'</td>
                                                                      <td>'.$key['prod_price'].'</td>
                                                                      <td>'.$total.'</td>
                                                                    </tr>';  
                                                                    $atotal+=$total;
                                                            }
                                                          echo '<tr><td></td><td></td><td><strong>Total</strong></td><td><strong>'.$atotal.'</strong></td></tr>';
                                                          
                                                      }
                                                      echo '</table></div></div>';
                                                    }
                                                    }
                                                else {
                                                  echo "<div class='alert alert-danger alert-dismissable'><button type='button' class='close' data-dismiss='alert'aria-hidden='true'>&times;</button>NO RECORD... </div>";
                                                }
                                                
                                              echo '</section>

                                          </div>
                                          <div class="modal-footer">
                                              <button data-dismiss="modal" class="btn btn-default" type="button">Close</button>
                                              <button class="btn btn-success" type="button">Save changes</button>
                                          </div>
                                      </div>
                                  </div>
                              </div>';

                echo '<div  class="modal fade" id="payment'.$i.'" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                                  <div class="modal-dialog">
                                      <div class="modal-content">
                                          <div class="modal-header">
                                              <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                              <h4 class="modal-title">'.$customer['cust_fname'].''."'s".' Record</h4>
                                          </div>
                                          <div class="modal-body">';

                                          echo '
                                            <section class="panel" >
                                                  <div class="panel-body progress-panel">
                                                    <div class="row">
                                              <div class="col-lg-8 task-progress pull-left">
                                                      
                                                        <img class="img-circle" src="'.$customer['cust_img'].'" width="50">
                                                         '.$customer['cust_lname'].', '.$customer['cust_fname'].'                              
                                                      </div>
                                                      <div class="col-lg-4">
                                                        <span class="profile-ava pull-right">';
                                                        
                                                          $balance = $gross_rec - $amount;
                                                          echo "<div style='margin-right:;'><b>Balance: $balance  <br>
                                                              Paid: $amount <br>Gross: $gross_rec</b></div>
                                                        
                                                              
                                                        </span>                                
                                                      </div></div></div>";
                                            if(count($getCustPayment) > 0){

                              echo "<table class='table table-stripped'>";
                              echo "<th>Card No</th><th>Card Type</th><th>Payment</th><th>Date Time</th><th>Staff</th>";

                                echo "<input type='hidden' id='img' value='$img'>";
                              $ctr=0;
                              foreach ($getCustPayment as $value) {
                                $ctr++;
                                $d = strtotime($value['payment_date']);
                                $p_id = $value['payment_id'];
                                $idd = $value['cust_id'];
                                $amount = $value['payment_amount'];
                                $date = Date("F j, Y g:i: A",$d);
                               $getImgStaff = $this->model->getStaffImgINPayment($p_id);
                                echo '<tr>';

                                  echo "<td>".$value['card_no']."</td>";
                                  echo "<td>".$value['card_type']."</td>";
                                  
                                  if($value['ack_payment']==NULL){echo "<td>".$value['payment_amount']."</td>";}
                                  else{echo "<td>".$value['ack_payment']."</td>";}
                                  echo "<td>".$date."</td>";
                                  if ($value['emp_id'] != NULL) {
                                    foreach ($getImgStaff as $keys) {
                                    $staff_img = $keys['emp_img'];
                                    $emp_nickname = $keys['emp_nickname'];

                                     echo "<td><img class='img-circle' src='".$staff_img."' width='30'><br><i class='small text-muted'>".$emp_nickname."</i></td>";
                                   }
                                  }
                                  else{
                                    echo "<td><p id='changeme$ctr'><a href='#' onclick='Acknowledge_Payment($amount,$id,$p_id,$ctr)' class='fa fa-circle-o'></a></p></td>";
                                  }
                                  
                                echo '</tr>';
                              }
                              echo '</table>';
                             
                            }
                            else {
                              echo "<div class='alert alert-danger alert-dismissable'><button type='button' class='close' data-dismiss='alert'aria-hidden='true'>&times;</button>NO PAYMENT RECORD... </div>";
                            }
                                          echo '</section></div>
                                          <div class="modal-footer">
                                              <button data-dismiss="modal" class="btn btn-default" type="button">Close</button>
                                              <button class="btn btn-success" type="button">Save changes</button>
                                          </div>
                                      </div>
                                  </div>
                              </div>';
                            }
              ?>

              