<?php
	include_once("model/Model.php");
	class Controller{
		public	$model;
		public	function __construct(){		
			$this->model = new Model();
		}
		public function invoke(){
			$this->Delete();
			$this->Update();
			$this->Retrieve();
			$this->Create();
			$this->Logout();
			$this->ValidateLogin();
			$this->AUTH();
		}
		
		public function AUTH(){
			if(isset($_GET['auth'])){
				$auth = $_GET['auth'];
				include 'view/Auth/'.$auth.'.php';
			}
			else if(isset($_GET['homepage'])){
				$homepage = null;
				$flag = rtrim($_GET['homepage'], '/');

				$page = array("Home","Employee/Register","Employee/Update","Department/Register","Department/Update","Product/Register","Product/Update");
				for($i=0;$i<count($page);$i++){
					if($flag == $page[$i]){
						$homepage = $flag;
						if($homepage == "Home"){
							$customer_count = $this->model->getCustomerDetails();
							$gross_rec = $this->model->GetTotalSales();
	                		$amount = $this->model->GetPaymentSales();
							include 'view/Homepage/AdminHeader.php';
					 		include 'view/Homepage/'.$homepage.'.php';
					 		include 'view/Homepage/AdminFooter.php';
						}
						else{
							include 'view/Homepage/AdminHeader.php';
					 		include 'view/Homepage/'.$homepage.'.php';
					 		include 'view/Homepage/AdminFooter.php';
				 		}
					}
					else $homepage = $homepage;
				}
			 		
			 }
			 else{
			
				include 'view/Auth/Login.php';
				
			}	
			
		}
		//
		public function ValidateLogin(){
			if(isset($_POST['login_admin'])){
				$username = $_POST['username'];
				$password = $_POST['password'];
				$row = $this->model->ValidateAdminLogin(array($username,$password));
				if(count($row) > 1){
                setcookie("admin_username", $row['admin_username'], time() + 86400, "/"); // 86400 = 1 day
                header("Location: index.php?homepage=Home");
            }
            else{
                header('location: index.php?auth=Authentication');
            }
			}
		}
		public function Logout(){
			if(isset($_GET['logout'])){
				if($_GET['logout'] == 1){
					//include 'view/Auth/FbConfig.php';
					//$FB->getLogoutURL(array("next"=>"index.php"));
					//$this->model->Admin_Logout();
					$this->model->FbLogout();
					 
				}
			}
		}
		//
		public function Create(){
			//EMPLOYEE
			if(isset($_POST['register_employee'])){
				$lname = $_POST['lname'];
				$fname = $_POST['fname'];
				$age = $_POST['age'];
				$gender = $_POST['gender'];
				$address = $_POST['address'];
				$contact = $_POST['contact'];
				$dept_id = $_POST['department'];
				$position = $_POST['position'];
				$this->model->RegisterEmployee(array($lname,$fname,$age,$gender,$address,$contact,$dept_id,$position,1));
		        setcookie("flag", "ok", time() + 5, "/");
				header("Location: index.php?homepage=Employee/Register");
			}
			//DEPARTMENT
			if(isset($_POST['register_department'])){
				$dept_code = $_POST['dept_code'];
				$dept_name = $_POST['dept_name'];
				$this->model->RegisterDepartment(array($dept_code, $dept_name,1));
		        setcookie("flag", "ok", time() + 5, "/");
				header("Location: index.php?homepage=Department/Register");
			}
			//PRODUCT
			if(isset($_POST['register_product'])){
				$prod_code = $_POST['prod_code'];
				$prod_desc = $_POST['prod_desc'];
				$prod_qty = $_POST['prod_qty'];
				$prod_price = $_POST['prod_price'];
				$this->model->RegisterProduct(array($prod_code,$prod_desc,$prod_qty,$prod_price,1));
		        setcookie("flag", "ok", time() + 5, "/");
				header("Location: index.php?homepage=Product/Register");
			}
		}
		public function Retrieve(){
			if(isset($_GET['homepage'])){
				$homepage = rtrim($_GET['homepage'], '/');
					
				//EMPLOYEE
				if($homepage=="Employee/View"){
					$employee = $this->model->ViewEmployeeInfo();
					include 'view/Homepage/AdminHeader.php';
				 	include 'view/Homepage/'.$homepage.'.php';
				 	include 'view/Homepage/AdminFooter.php';
				}
				if($homepage=="Employee/UnActive"){
					$unactive_employee = $this->model->ViewUnActiveEmployeeInfo();
					include 'view/Homepage/AdminHeader.php';
				 	include 'view/Homepage/'.$homepage.'.php';
				 	include 'view/Homepage/AdminFooter.php';
				}
				//DEPARTMENT
				if($homepage=="Department/View"){
					$department = $this->model->ViewDepartmentInfo();
					include 'view/Homepage/AdminHeader.php';
				 	include 'view/Homepage/'.$homepage.'.php';
				 	include 'view/Homepage/AdminFooter.php';
				}
				if($homepage=="Department/UnActive"){
					$unactive_department = $this->model->ViewUnActiveDepartmentInfo();
					include 'view/Homepage/AdminHeader.php';
				 	include 'view/Homepage/'.$homepage.'.php';
				 	include 'view/Homepage/AdminFooter.php';
				}
				//PRODUCT
				if($homepage=="Product/View"){
					$product = $this->model->ViewProductInfo();
					include 'view/Homepage/AdminHeader.php';
				 	include 'view/Homepage/'.$homepage.'.php';
				 	include 'view/Homepage/AdminFooter.php';
				}
				if($homepage=="Product/UnActive"){
					$unactive_product = $this->model->ViewUnActiveProductInfo();
					include 'view/Homepage/AdminHeader.php';
				 	include 'view/Homepage/'.$homepage.'.php';
				 	include 'view/Homepage/AdminFooter.php';
				}
				//SALES
				if($homepage=="Sales/Inventory"){
					$dis_date = $this->model->GetDistinctDateOrderlist();
					$gross_rec = $this->model->GetTotalSales();
	                $amount = $this->model->GetPaymentSales();
					include 'view/Homepage/AdminHeader.php';
				 	include 'view/Homepage/'.$homepage.'.php';
				 	include 'view/Homepage/AdminFooter.php';
				}
				if($homepage=="Sales/Sales"){
					$sales = $this->model->Sales();
					include 'view/Homepage/AdminHeader.php';
				 	include 'view/Homepage/'.$homepage.'.php';
				 	include 'view/Homepage/AdminFooter.php';
				}
				//payment
				if($homepage=="CustomerAccount"){
					$payment = $this->model->CustomerAccount();
					$Min = $this->model->getMinNoCustomerID();
			        $Max = $this->model->getMaxNoCustomerID();
			        
			        foreach ($Max as $key) {$max = $key['max'];}
                    foreach ($Min as $key) {$min = $key['min'];}
					include 'view/Homepage/AdminHeader.php';
				 	include 'view/Homepage/'.$homepage.'/Account.php';
				 	include 'view/Homepage/AdminFooter.php';
				}	
			}
		}
		public function Update(){
			if(isset($_GET['active'])){
				$active = $_GET['active'];
				$id = $_GET['id'];
				//ACTIVE
				if($active == "employee"){
					setcookie("update", $id, time() + 5, "/");
					$this->model->ActiveEmployee(array($id));
					header('Location: index.php?homepage=Employee/UnActive');
				}
				else if($active == "product"){
					setcookie("update", $id, time() + 5, "/");
					$this->model->ActiveProduct(array($id));
					header('Location: index.php?homepage=Product/UnActive');
				}
				else if($active == "department"){
					setcookie("update", $id, time() + 5, "/");
					$this->model->ActiveDepartment(array($id));
					header('Location: index.php?homepage=Department/UnActive');
				}
			}
			else {
			//EMPLOYEE
				if(isset($_POST['update_employee'])){
					$emp_id = $_POST['id'];
					$fname = $_POST['fname'];
					$lname = $_POST['lname'];
					$age = $_POST['age'];
					$gender = $_POST['gender'];
					$address = $_POST['address'];
				    $contact = $_POST['contact'];
				    $dept = $_POST['department'];
				    $position = $_POST['position'];
				    $data = array($lname,$fname,$age,$gender,$address,$contact,$dept,$position,$emp_id);
			        setcookie("update", $emp_id, time() + 5, "/");
					$this->model->UpdateEmployee($data);
					header('Location: index.php?homepage=Employee/View');
				}
				//DEPARTMENT
				if(isset($_POST['update_department'])){
					$dept_id = $_POST['dept_id'];
					$dept_code = $_POST['dept_code'];
					$dept_name = $_POST['dept_name'];
				    $data = array($dept_code,$dept_name,$dept_id);
			        setcookie("update", $dept_id, time() + 5, "/");
					$this->model->UpdateDepartment($data);
					header('Location: index.php?homepage=Department/View');
				}
				//PRODUCT
				if(isset($_POST['update_product'])){
					$prod_id = $_POST['prod_id'];
					$prod_code = $_POST['prod_code'];
					$prod_desc = $_POST['prod_desc'];
					$prod_qty = $_POST['prod_qty'];
					$prod_price = $_POST['prod_price'];
				    $data = array($prod_code,$prod_desc,$prod_qty,$prod_price,$prod_id);
			        setcookie("update", $prod_id, time() + 5, "/");
					$this->model->UpdateProduct($data);
					header('Location: index.php?homepage=Product/View');
				}
			}
		}
		public function Delete(){
			if(isset($_GET['id']) && isset($_GET['page'])){
				$id = $_GET['id'];
				$page = $_GET['page'];
				if($page=="employee"){
					$this->model->UnActiveEmployee(array($id));
					header('Location: index.php?homepage=Employee/View');	
				}
				else if($page=="product"){
					$this->model->UnActiveProduct(array($id));
					header('Location: index.php?homepage=Product/View');	
				}
				else{
					$this->model->UnActiveDepartment(array($id));
					header('Location: index.php?homepage=Department/View');	
				}
			}
		}
	}	
?>